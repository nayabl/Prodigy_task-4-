// Basic interactivity: mobile nav toggle, header scroll shadow, active nav links,
// project modal, contact form mailto (client-side), and section highlight.

document.addEventListener('DOMContentLoaded', () => {
  const header = document.getElementById('site-header');
  const navToggle = document.getElementById('nav-toggle');
  const navMenu = document.getElementById('nav-menu');
  const navLinks = Array.from(document.querySelectorAll('.nav__link'));
  const sections = Array.from(document.querySelectorAll('main section[id], footer'));
  const projects = document.querySelectorAll('.project-card');

  // Mobile nav toggle
  navToggle.addEventListener('click', () => {
    const isOpen = navMenu.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', String(isOpen));
  });

  // Close mobile nav after clicking a link
  navLinks.forEach(a => {
    a.addEventListener('click', () => {
      if (navMenu.classList.contains('open')) {
        navMenu.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  });

  // Header shadow on scroll
  const onScroll = () => {
    if (window.scrollY > 10) header.classList.add('scrolled');
    else header.classList.remove('scrolled');
  };
  window.addEventListener('scroll', onScroll);
  onScroll();

  // Highlight active nav link (IntersectionObserver)
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      const id = entry.target.id;
      if (!id) return;
      const link = navLinks.find(a => a.getAttribute('href') === `#${id}`);
      if (!link) return;
      if (entry.isIntersecting) {
        navLinks.forEach(l => l.classList.remove('active'));
        link.classList.add('active');
      }
    });
  }, { threshold: 0.55 });

  sections.forEach(s => observer.observe(s));

  // Projects modal
  const modal = document.getElementById('project-modal');
  const modalTitle = document.getElementById('modal-title');
  const modalDesc = document.getElementById('modal-desc');
  const modalTech = document.getElementById('modal-tech');
  const modalLink = document.getElementById('modal-link');
  const modalClose = modal.querySelector('.modal__close');
  const modalOverlay = modal.querySelector('.modal__overlay');

  function openModal(title, desc, tech, href) {
    modalTitle.textContent = title;
    modalDesc.textContent = desc;
    modalTech.textContent = tech;
    modalLink.href = href || '#';
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }
  function closeModal() {
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  projects.forEach(card => {
    card.addEventListener('click', () => {
      openModal(
        card.dataset.title || 'Project',
        card.dataset.desc || '',
        card.dataset.tech || '',
        card.dataset.link || '#'
      );
    });
  });
  modalClose.addEventListener('click', closeModal);
  modalOverlay.addEventListener('click', closeModal);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.getAttribute('aria-hidden') === 'false') closeModal();
  });

  // Contact form: opens mail client with mailto (client-side)
  const form = document.getElementById('contact-form');
  const feedback = document.getElementById('form-feedback');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const message = form.message.value.trim();

    if (!name || !email || !message) {
      feedback.textContent = 'Please fill all fields.';
      return;
    }

    const to = 'your.email@example.com'; // <-- change to your email
    const subject = encodeURIComponent(`Portfolio message from ${name}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\n${message}`);
    const mailto = `mailto:${to}?subject=${subject}&body=${body}`;

    // Try to open user's mail client
    window.location.href = mailto;

    feedback.textContent = 'Your email client should open. If not, copy-paste your message to your mail app.';
    form.reset();
  });
});
